﻿//---------------------------------------------
//Dimensions réelles de l'écran
var   _sWidth;
var   _sHeight;
   //Dimensions surlequelles se base le jeu
var   gWidth=300;
var   gHeight=600;

function start(width_,height_){
    //Connaitre les dimensions réelles de l'écran
       _sWidth=width_;
       _sHeight=height_;

       main.width= width_;
       main.height= height_;
       calculDimensions();
       gotoSplashPage();

}


// Accéder aux dimensions du main
function getWidth(){
    return _sWidth;
}
function getHeight(){
    return _sHeight;
}
//Gestion des écrans
var _scenePageLevel1;
var _scenePageLevel2;

var _gameOver;

function gotoSplashPage(){
     main.launchPage('SplashPage');
}
function gotoMenuPage(){
     main.launchPage('MenuPage');
}
function gotoMissionsPage(){
     main.launchPage('MissionsPage');
}
function gotoScenePageLevel1(){
     _scenePageLevel1 =main.launchPage('ScenePageLevel1');
}

function gotoScenePageLevel2(){
    _scenePageLevel2= main.launchPage("ScenePageLevel2");
}

function gotoScoresPage(){
    main.launchPage("ScoresPage");
}

function gotoAproposPage(){
    main.launchPage("AproposPage");
}

function gotoGameOverPage(){
    _gameOver = main.launchPage("GameOverPage");

}
//-------------------------------------------------
//Choix des levels
var _leLevel=1;

function levelChoisi(level_){
    _leLevel= level_;
}
function levelSelectionne(){
     return  _leLevel;
}



//-------------------------------------------------
function choisirImage(){ //Choisir l'image en fonction des dimensions de l'écran
/*J'ai cherché en vain des moyens pour gérer les écrans avec Qt , alors j'ai mené une réflexion.
-Créer les images avec les dimensions voulues , de base (w:640,h:960) et créer les mm images mais en doublant leurs dimensions(pour les écrans assez larges)+hd
-Choisir des dimensions pour l'écran de démarrage ,ceci en fonction de l'aspect du jeu(w:300,h:600)
Pour mon jeu:
-Si h<=700px et w<=640px alors prendre les images de base
-Sinon prendre les images +hd
-Faire des anchors
Donc cette fonction retournera l'url de l'image en fonction des dimensions
*/
   if (_sHeight<=700 && _sWidth<=640){
       return '';
   }
   else{ // High dimensions
       return "+hd/";
   }
}
//Dynamic resize
function choisirDimension(smDimension_,hdDimension_){
    if(choisirImage()==''){
        return smDimension_;
    }else{
        return hdDimension_;
    }
}

// fonctions d'ajout de meteorites et pierres précieuses
var _pLargeur, _gLargeur ;

function calculDimensions(){
    _pLargeur=7;
    _gLargeur= main.width-main.tGame.choisirDimension(25,50)-18;
}

function abscisseAleatoire(min_, max_, entier_){

    if(!entier_){
        return Math.random() * (max_-min_) + min_;
    }else{
        return Math.floor(Math.random() * (max_ - min_ +1) + min_);
    }


}

function ajoutMeteorite1(){
   var abscisseChoisi= abscisseAleatoire(_pLargeur,_gLargeur);

    modelMeteorite1.append( {"x": abscisseChoisi , "y":60} );

}

function ajoutMeteorite2(){
    var abscisseChosi= abscisseAleatoire(_pLargeur,_gLargeur);

   modelMeteorite2.append( {"x":abscisseChosi ,"y":60} );
}

function ajoutMeteorite3(){
    var abscisseChoisi= abscisseAleatoire(_pLargeur,_gLargeur);

    modelMeteorite3.append( {"x": abscisseChoisi , "y":60} );
}

function ajoutEau(){
    var abscisseChosi= abscisseAleatoire(_pLargeur,_gLargeur);

       eau.append( {"x":abscisseChosi ,"y":60} );
}

function ajoutEtoile(){
    var abscisseChosi= abscisseAleatoire(_pLargeur,_gLargeur);

      etoile.append( {"x":abscisseChosi ,"y":60} );
}

function ajoutDiamant(){
    var abscisseChosi= abscisseAleatoire(_pLargeur,_gLargeur);

       diamant.append( {"x":abscisseChosi ,"y":60} );
}


//-------------------------------------------------//Mécanismes de vie et de scores
var _score=0;
var _scoreComparaison1=0;
var _scoreComparaison2=0;
var _vie  =4;

function scoreAugmente(incrementScore_, level_){
    _score+=incrementScore_;

    if(level_==1){
        _scenePageLevel1.modifierScore(_score);
        var val= intervalApparition(level_);
        _scenePageLevel1.augmentationApparition(val);
    }
    else if(level_ ==2){
        _scenePageLevel2.modifierScore(_score);
        var val= intervalApparition(level_);
        _scenePageLevel2.augmentationApparition(val);
    }

}


function scoreGameOver(level){
    if(level== 1){
        return _scoreComparaison1;
    }else if(level== 2){
        return _scoreComparaison2;
    }
}

var nbVieMeteorites1=3;
var nbVieMeteorites2=2;
var nbVieMeteorites3=1;

function enleveVie(typeMeteorites){

    if (nbVieMeteorites1==0){
        nbVieMeteorites1=3;
    }
    if (nbVieMeteorites2==0){
        nbVieMeteorites2=2;
    }
    if (nbVieMeteorites3==0){
        nbVieMeteorites3=1;
    }

    if (typeMeteorites==1){
        nbVieMeteorites1 -=1;
        return nbVieMeteorites1;

    }else if(typeMeteorites==2){
        nbVieMeteorites2 -=1;
        return nbVieMeteorites2;

    }else if(typeMeteorites==3){
        nbVieMeteorites3 -=1;
        return nbVieMeteorites3;
    }

}

function arretLevel1(){
    _scenePageLevel1.arreterTimerLevel1();
        modelMeteorite1.clear();
        modelMeteorite2.clear();
        _scoreComparaison1= _score;
        _score=0;
        _vie  =4;
        _scenePageLevel1.modifierVie(_vie);

        gotoGameOverPage();
}

function arretLevel2(){
        _scenePageLevel2.arreterTimerLevel2();
        modelMeteorite1.clear();
        modelMeteorite2.clear();
        modelMeteorite3.clear();
        _scoreComparaison2= _score;
        _score=0;
        _vie  =4;
        _scenePageLevel2.modifierVie(_vie);

        gotoGameOverPage();
}

function vieAugmente(typeLevel_){
   if(_vie<2){
    _vie+=1;

       if(typeLevel_==1){
      _scenePageLevel1.modifierVie(_vie);
       }

       else if(typeLevel_==2){
      _scenePageLevel2.modifierVie(_vie);
       }

   }

}

function retourneVie(){
    return _vie;
}

function vieDiminue(typeLevel_){
    _vie--;

    if(typeLevel_==1){
   _scenePageLevel1.modifierVie(_vie);
    }

    if(_vie== 0 && typeLevel_==1){
        arretLevel1();
    }

    else {
        if(typeLevel_==2){
       _scenePageLevel2.modifierVie(_vie);
        }

        if(_vie== 0 && typeLevel_==2){
            arretLevel2();
        }
    }


 }

//Gestion de la chute des meteorites
//Vitesse d'apparition
var _mScoreL1= 100000;
var _mScoreL2= 1000000;

var _scoreDiviseL1= [0,50,100,150,200,-1];
var _scoreDiviseL2= [0,50,100,150,200,-1];

function comparaison(nombre_, mini_, maxi_){
        if(maxi_!=-1){
            if(mini_<= nombre_ && nombre_ < maxi_){
                return true;
            }
        }
        else {
            return nombre_ >= mini_ ;
        }
}


function intervalApparition(level_){
    var tab;
    var leScore=0;

    if(level_== 1){
        tab= _scoreDiviseL1;
        leScore=  _scenePageLevel1.retourneScore();
    }else if(level_== 2){
        tab= _scoreDiviseL2;
        leScore= _scenePageLevel2.retourneScore();
    }

    var i=0;
    for (i=0; i<6; i++){
        if( comparaison(leScore, tab[i], tab[i+1]) ){
            return 3500-(i*500);
        }
    }
}

// Gestion des meilleurs scores
var _meilleurScoreLevel1= 0;
var _meilleurScoreLevel2= 0;

function lireMeilleursScores(mScorelevel1_, mScorelevel2_){

    _meilleurScoreLevel1= mScorelevel1_;
    _meilleurScoreLevel2= mScorelevel2_;
}


function afficherMeilleursScores(level_){
    if(level_==1){
        return _meilleurScoreLevel1;
    }
    else if(level_==2){
        return _meilleurScoreLevel2;
    }
}

function enregistrerLeScore(level_){

    if ( (_meilleurScoreLevel1 < _scoreComparaison1) && (level_== 1) ){
        _meilleurScoreLevel1= _scoreComparaison1;
        miseajourscore.enregistrerScore(_meilleurScoreLevel1, 1);
    }
    else if( (_meilleurScoreLevel2 < _scoreComparaison2) && (level_== 2) ){
        _meilleurScoreLevel2= _scoreComparaison2;
        miseajourscore.enregistrerScore(_meilleurScoreLevel2, 2);
    }

}
